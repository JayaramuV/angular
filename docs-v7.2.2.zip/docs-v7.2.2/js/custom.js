$(document).ready(function() {
	// Start writing your custom functions here.
	// All the necessary pluigns are already loaded.
});