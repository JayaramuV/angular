import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-board',
  templateUrl: './task-board.component.html',
  styleUrls: [
    './task-board.component.scss',
    '../../../../assets/icon/icofont/css/icofont.scss'
  ]
})
export class TaskBoardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
