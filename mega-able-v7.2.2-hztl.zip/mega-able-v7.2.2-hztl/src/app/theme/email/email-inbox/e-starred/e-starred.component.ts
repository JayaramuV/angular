import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e-starred',
  templateUrl: './e-starred.component.html',
  styleUrls: [
    './e-starred.component.scss',
    '../../../../../assets/icon/icofont/css/icofont.scss'
  ]
})
export class EStarredComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
