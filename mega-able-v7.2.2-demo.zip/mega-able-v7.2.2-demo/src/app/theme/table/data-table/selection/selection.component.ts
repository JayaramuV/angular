import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selection',
  templateUrl: './selection.component.html',
  styleUrls: [
    './selection.component.scss',
    '../../../../../assets/icon/icofont/css/icofont.scss'
  ]
})
export class SelectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
