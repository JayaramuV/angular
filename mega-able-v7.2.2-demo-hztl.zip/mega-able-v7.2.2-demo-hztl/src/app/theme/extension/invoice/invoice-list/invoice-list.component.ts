import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-list',
  templateUrl: './invoice-list.component.html',
  styleUrls: [
    './invoice-list.component.scss',
    '../../../../../assets/icon/icofont/css/icofont.scss'
  ]
})
export class InvoiceListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
