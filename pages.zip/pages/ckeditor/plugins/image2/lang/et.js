/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'et', {
	alt: 'Alternatiivne tekst',
	btnUpload: 'Saada serverisse',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Pildi info',
	lockRatio: 'Lukusta kuvasuhe',
	menu: 'Pildi omadused',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Lähtesta suurus',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Pildi omadused',
	uploadTab: 'Lae üles',
	urlMissing: 'Pildi lähte-URL on puudu.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
