/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uploadwidget', 'id', {
	abort: 'Pengunggahan dibatalkan oleh pengguna',
	doneOne: 'Berkas telah berhasil diunggah',
	doneMany: 'Pengunggahan berkas %1 berhasil',
	uploadOne: 'Mengunggah berkas ({percentage}%)...',
	uploadMany: 'Pengunggahan berkas {current} dari {max} berhasil ({percentage}%)...'
} );
